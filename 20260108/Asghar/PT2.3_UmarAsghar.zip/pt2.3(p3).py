nomcog = input ("Escriu el teu nom i cognom: ")
print (nomcog)
print (nomcog.upper())
print (nomcog.lower())