nomcog = input ("Escriu el teu nom i cognom: ")
print (nomcog)
print (nomcog.upper())
print (nomcog.lower())

lletres = len(nomcog) - 2
print (lletres)