frase = input("Escriu una frase llarga!")
v1 = input("Escriu el primer valor: ")
v1 = int(v1)
v2 = input("Escriu el segon valor: ")
v2 = int(v2)

print (frase[v1:v2])