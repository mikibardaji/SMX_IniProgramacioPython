v1 =input("Pon un numero: ")
v1 = int(v1)

#suma
v1 += 5
print (v1)
#resta
v1 -= 2
print (v1)
